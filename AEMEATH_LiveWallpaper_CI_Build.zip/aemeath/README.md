# AEMEATH Android Live Wallpaper

Wallpaper-only Android Studio project. No overlay mode and no touch interactions. See `app/src/main/README.md` for build instructions and limitations.


## Build APK on GitHub Actions (no local Android SDK required)
1. Create a new GitHub repository and upload the contents of this `aemeath` folder (so `settings.gradle` and `app/` are at the repository root).
2. Open the repository's **Actions** tab and enable Actions if prompted.
3. Select **Build AEMEATH Live Wallpaper APK** and click **Run workflow**, or push a commit to `main`/`master`.
4. When the workflow finishes successfully, open the run and download `AEMEATH-live-wallpaper-debug-apk` under **Artifacts**.

The workflow builds a debug APK only. It has not yet been executed in a hosted runner, so compilation and runtime behavior remain unverified until the first run completes.
