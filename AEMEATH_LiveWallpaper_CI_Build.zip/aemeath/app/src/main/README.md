# AEMEATH Live Wallpaper (Android project)

Wallpaper-only first prototype based on the supplied AEMEATH v1.2.3 source/assets.

## Included
- Live wallpaper service (`WallpaperService`)
- Touch disabled (`setTouchEventsEnabled(false)`)
- Adaptive normalized movement bounds based on wallpaper surface dimensions
- Idle float and occasional curved flight motion
- Reuses the included idle/fly/expression PNG frames
- Settings activity for size, opacity and speed
- No overlay permission/service/code

## Build an APK with Android Studio
1. Install Android Studio with Android SDK Platform 35 and a JDK 17 or newer.
2. Open this project folder (the folder containing `settings.gradle`).
3. Allow Gradle sync to download Android Gradle Plugin 8.7.3 and Kotlin plugin 2.0.21.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location after a successful build.

## Install and select wallpaper
Install the generated APK, open **AEMEATH 배경화면**, adjust the sliders, tap **라이브 배경화면 미리보기**, then apply it to the Home screen.

## Important status
This source project has not been compiled or tested on a physical device in the current environment. The current environment has Java but no Android SDK/Gradle installation and cannot reach the internet to fetch build dependencies, so an APK could not be generated here. Validate the build and behavior in Android Studio before daily use.
