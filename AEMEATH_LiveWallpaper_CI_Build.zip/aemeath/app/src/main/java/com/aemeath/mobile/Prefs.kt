package com.aemeath.mobile
import android.content.Context
object Prefs {
 private const val FILE="aemeath"
 fun get(c:Context,k:String,d:Float)=c.getSharedPreferences(FILE,0).getFloat(k,d)
 fun put(c:Context,k:String,v:Float)=c.getSharedPreferences(FILE,0).edit().putFloat(k,v).apply()
 fun getInt(c:Context,k:String,d:Int)=c.getSharedPreferences(FILE,0).getInt(k,d)
 fun putInt(c:Context,k:String,v:Int)=c.getSharedPreferences(FILE,0).edit().putInt(k,v).apply()
}