package com.aemeath.mobile

import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class AmesWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = WallpaperEngine()

    inner class WallpaperEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var renderer: Sprite? = null
        private var framePosted = false
        private val drawTask = object : Runnable {
            override fun run() {
                framePosted = false
                if (!isVisible) return
                var canvas: android.graphics.Canvas? = null
                try {
                    canvas = surfaceHolder.lockCanvas()
                    if (canvas != null) {
                        if (renderer == null) renderer = Sprite(this@AmesWallpaperService)
                        canvas.drawColor(android.graphics.Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR)
                        renderer?.draw(canvas)
                    }
                } catch (_: Exception) {
                } finally {
                    if (canvas != null) try { surfaceHolder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
                }
                scheduleNextFrame()
            }
        }

        init { setTouchEventsEnabled(false) }

        private fun scheduleNextFrame() {
            if (!framePosted && isVisible) {
                framePosted = true
                handler.postDelayed(drawTask, 33L)
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) scheduleNextFrame() else {
                handler.removeCallbacks(drawTask)
                framePosted = false
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            scheduleNextFrame()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            scheduleNextFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            handler.removeCallbacks(drawTask)
            framePosted = false
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            handler.removeCallbacks(drawTask)
            renderer = null
            super.onDestroy()
        }
    }
}
