package com.aemeath.mobile

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFFFFF7FB.toInt())
        }
        root.addView(TextView(this).apply { text = "AEMEATH 라이브 배경화면"; textSize = 24f; setTextColor(0xFF7A3158.toInt()) })
        root.addView(TextView(this).apply {
            text = "터치 없이 자동으로 떠다니고 비행하는 에이메스\n설정을 바꾼 뒤 배경화면 미리보기에서 적용해줘."
            textSize = 15f; setPadding(0, 12, 0, 18)
        })
        addSlider(root, "캐릭터 크기", "size", 35, 200, 100, "%.2f×")
        addSlider(root, "투명도", "opacity", 15, 100, 100, "%")
        addSlider(root, "움직임 속도", "speed", 40, 250, 100, "×")
        root.addView(Button(this).apply {
            text = "라이브 배경화면 미리보기"
            setOnClickListener {
                try {
                    startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(this@MainActivity, AmesWallpaperService::class.java)))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "배경화면 선택 화면을 열 수 없어. 설정에서 라이브 배경화면을 선택해줘.", Toast.LENGTH_LONG).show()
                }
            }
        })
        root.addView(TextView(this).apply {
            text = "화면 비율에 맞춰 이동 범위가 자동 조정돼. 이 앱은 터치 이벤트를 사용하지 않아."
            textSize = 13f; setPadding(0, 16, 0, 0)
        })
        setContentView(root)
    }

    private fun addSlider(root: LinearLayout, title: String, key: String, min: Int, max: Int, initial: Int, suffix: String) {
        val label = TextView(this).apply { textSize = 16f; setPadding(0, 12, 0, 2) }
        fun updateLabel(value: Int) {
            val shown = when (key) {
                "opacity" -> "$value%"
                "size" -> String.format("%.2f×", value / 100f)
                else -> String.format("%.2f×", value / 100f)
            }
            label.text = "$title · $shown"
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = (Prefs.get(this@MainActivity, key, initial / 100f) * 100).toInt().coerceIn(min, max) - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + min
                    Prefs.put(this@MainActivity, key, value / 100f)
                    updateLabel(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        updateLabel(seek.progress + min)
        root.addView(label)
        root.addView(seek, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
}
