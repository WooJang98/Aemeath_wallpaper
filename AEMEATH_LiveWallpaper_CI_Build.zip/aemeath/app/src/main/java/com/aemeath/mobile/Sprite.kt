package com.aemeath.mobile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Wallpaper-only renderer. No touch handling and no Android View dependency. */
class Sprite(context: Context) {
    private val appContext = context.applicationContext
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private fun load(name: String): Bitmap? = try {
        appContext.assets.open("frames/$name").use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) { null }

    private val idleFrames = listOf("calm_idle_01.png", "calm_idle_02.png", "calm_idle_03.png", "calm_idle_04.png").mapNotNull(::load)
    private val flightFrames = listOf("tilt_fly_01.png", "tilt_fly_02.png", "tilt_fly_03.png", "tilt_fly_04.png", "tilt_fly_05.png").mapNotNull(::load)
    private val expressionFrames = listOf("front_open_01.png", "front_open_02.png", "front_open_03.png", "front_open_04.png", "happy_01.png").mapNotNull(::load)

    private enum class Mode { IDLE, FLIGHT }
    private var mode = Mode.IDLE
    private var x = 0.5f
    private var y = 0.78f
    private var startX = x
    private var startY = y
    private var endX = x
    private var endY = y
    private var peakY = 0.22f
    private var flightStart = 0L
    private var flightDuration = 5000L
    private var nextFlightAt = System.currentTimeMillis() + Random.nextLong(18000L, 38000L)
    private var lastFrameAt = 0L
    private var frameIndex = 0
    private var phase = 0f
    private var facingRight = true
    private var lastWidth = 0
    private var lastHeight = 0

    fun draw(canvas: Canvas, now: Long = System.currentTimeMillis()) {
        if (idleFrames.isEmpty() && flightFrames.isEmpty()) return
        val w = canvas.width.toFloat()
        val h = canvas.height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (lastWidth != canvas.width || lastHeight != canvas.height) {
            lastWidth = canvas.width; lastHeight = canvas.height
            x = x.coerceIn(0.12f, 0.88f)
            y = 0.78f
            if (mode == Mode.FLIGHT) mode = Mode.IDLE
            nextFlightAt = now + Random.nextLong(12000L, 28000L)
        }

        val speed = Prefs.get(appContext, "speed", 1f).coerceIn(0.4f, 2.5f)
        phase += 0.045f * speed
        when (mode) {
            Mode.IDLE -> {
                // Stay in a lower band like a desktop idle companion; band scales with screen ratio.
                val portrait = h >= w
                val baseY = if (portrait) 0.79f else 0.76f
                val ySwing = if (portrait) 0.035f else 0.055f
                x += (if (facingRight) 1f else -1f) * (w / max(h, 1f)) * 0.0017f * speed
                if (x > 0.88f) { x = 0.88f; facingRight = false }
                if (x < 0.12f) { x = 0.12f; facingRight = true }
                y = baseY + sin(phase * 1.15f) * ySwing
                if (now >= nextFlightAt) beginFlight(now)
            }
            Mode.FLIGHT -> {
                val t = ((now - flightStart).toFloat() / flightDuration.toFloat() * speed).coerceIn(0f, 1f)
                val eased = 0.5f - cos(t * PI.toFloat()) * 0.5f
                val arc = sin(t * PI.toFloat())
                x = startX + (endX - startX) * eased + sin(phase * 1.4f) * 0.008f
                val baseY = startY + (endY - startY) * eased
                y = baseY - (baseY - peakY) * arc + sin(phase * 2f) * 0.006f
                if (t >= 1f) {
                    mode = Mode.IDLE
                    x = endX; y = endY
                    nextFlightAt = now + Random.nextLong(16000L, 42000L)
                }
            }
        }

        val frames = when {
            mode == Mode.FLIGHT && flightFrames.isNotEmpty() -> flightFrames
            expressionFrames.isNotEmpty() && now % 27000L < 1800L -> expressionFrames
            idleFrames.isNotEmpty() -> idleFrames
            else -> flightFrames
        }
        if (frames.isEmpty()) return
        val interval = (190f / speed).toLong().coerceAtLeast(65L)
        if (now - lastFrameAt >= interval) { frameIndex = (frameIndex + 1) % frames.size; lastFrameAt = now }
        val bitmap = frames[frameIndex % frames.size]
        val sizeScale = Prefs.get(appContext, "size", 1f).coerceIn(0.35f, 2f)
        val targetWidth = min(w * 0.25f * sizeScale, w * 0.48f)
        val targetHeight = targetWidth * bitmap.height.toFloat() / bitmap.width.toFloat()
        val drawX = x * w
        val bob = sin(phase * 1.7f) * h * 0.003f
        val rect = RectF(drawX - targetWidth / 2f, y * h + bob - targetHeight / 2f,
            drawX + targetWidth / 2f, y * h + bob + targetHeight / 2f)
        paint.alpha = (Prefs.get(appContext, "opacity", 1f).coerceIn(0.15f, 1f) * 255).toInt()
        canvas.save()
        if (!facingRight) canvas.scale(-1f, 1f, drawX, y * h + bob)
        canvas.drawBitmap(bitmap, null, rect, paint)
        canvas.restore()
    }

    private fun beginFlight(now: Long) {
        mode = Mode.FLIGHT
        flightStart = now
        flightDuration = Random.nextLong(4200L, 6800L)
        startX = x; startY = y
        endX = Random.nextFloat().coerceIn(0.13f, 0.87f)
        endY = Random.nextFloat().coerceIn(0.68f, 0.84f)
        peakY = Random.nextFloat().coerceIn(0.14f, 0.34f)
        facingRight = endX >= startX
        frameIndex = 0
    }
}
